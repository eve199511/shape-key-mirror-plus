from .shape_key_mirror_plus import register, unregister

bl_info = {
    "name": "Shape Key Mirror Plus",
    "author": "Ciyorie (with GPT support)",
    "version": (1, 7),
    "blender": (4, 2, 0),
    "location": "Properties > Object Data > Shape Keys",
    "description": "Mirror shape key deltas with symmetry detection across multiple parts",
    "category": "Object",
}
